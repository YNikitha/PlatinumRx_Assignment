BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "booking_commercials" (
	"id"	VARCHAR,
	"booking_id"	VARCHAR,
	"bill_id"	VARCHAR,
	"bill_date"	TIMESTAMP,
	"item_id"	VARCHAR,
	"item_quantity"	DECIMAL,
	PRIMARY KEY("id"),
	FOREIGN KEY("booking_id") REFERENCES "bookings"("booking_id"),
	FOREIGN KEY("item_id") REFERENCES "items"("item_id")
);
CREATE TABLE IF NOT EXISTS "bookings" (
	"booking_id"	VARCHAR,
	"booking_date"	TIMESTAMP,
	"room_no"	VARCHAR,
	"user_id"	VARCHAR,
	PRIMARY KEY("booking_id"),
	FOREIGN KEY("user_id") REFERENCES "users"("user_id")
);
CREATE TABLE IF NOT EXISTS "items" (
	"item_id"	VARCHAR,
	"item_name"	VARCHAR,
	"item_rate"	DECIMAL,
	PRIMARY KEY("item_id")
);
CREATE TABLE IF NOT EXISTS "users" (
	"user_id"	VARCHAR,
	"name"	VARCHAR,
	"phone_number"	INTEGER,
	"mail_id"	VARCHAR,
	"billing_address"	VARCHAR,
	PRIMARY KEY("user_id")
);
INSERT INTO "booking_commercials" VALUES ('q34r-3q4o8-q34u','bk-09f3e-95hj','bl-0a87y-q340','2021-09-23 12:03:22','itm-a9e8-q8fu',3);
INSERT INTO "booking_commercials" VALUES ('q3o4-ahf32-o2u4','bk-09f3e-95hj','bl-0a87y-q340','2021-09-23 12:03:22','itm-a07vh-aer8',1);
INSERT INTO "booking_commercials" VALUES ('13l4r-oyfo8-3qk4','bk-q034-q4o','bl-34qhd-r7h8','2021-09-23 12:05:37','itm-a9e8-q8fu',0.5);
INSERT INTO "bookings" VALUES ('bk-09f3e-95hj','2021-09-23 07:36:48','rm-bhf9-aerjn','21wrcxuy-67erfn');
INSERT INTO "bookings" VALUES ('bk-q034-q4o','2021-09-23 12:05:37','rm-xyz-123','21wrcxuy-67erfn');
INSERT INTO "items" VALUES ('itm-a9e8-q8fu','Tawa Paratha',18);
INSERT INTO "items" VALUES ('itm-a07vh-aer8','Mix Veg',89);
INSERT INTO "users" VALUES ('21wrcxuy-67erfn','John Doe',9700000000,'john.doe@example.com','Some address');
INSERT INTO "users" VALUES ('21wrcxuy-67gsr','raju',9876543210,'raj.doe@example.com','XYZ address');
INSERT INTO "users" VALUES ('21wtsrahy-67erfn','vikram',9700062453,'vikram.doe@example.com','ABC address');
INSERT INTO "users" VALUES ('21wtsrahy-799erfn','pallavi',9778562453,'pallavi.doe@example.com','prakasam address');
COMMIT;
