WITH profits AS (
    SELECT
        cl.state,
        cs.cid,
        SUM(cs.amount) - ifnull(
            (SELECT SUM(amount) FROM expenses e WHERE e.cid = cs.cid AND strftime('%Y-%m', e.datetime) = '2021-09'),
            0
        ) AS profit
    FROM clinic_sales cs
    JOIN clinics cl ON cl.cid = cs.cid
    WHERE strftime('%Y-%m', cs.datetime) = '2021-09' -- Set your target month
    GROUP BY cl.state, cs.cid
)
SELECT state, cid, profit
FROM (
    SELECT state, cid, profit,
        RANK() OVER (PARTITION BY state ORDER BY profit ASC) AS rnk    -- ASC for least
    FROM profits
)
WHERE rnk = 2;
