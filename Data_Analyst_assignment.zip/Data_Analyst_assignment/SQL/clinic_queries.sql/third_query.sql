WITH 
    monthly_revenue AS (
        SELECT strftime('%Y-%m', datetime) AS month, SUM(amount) AS revenue
        FROM clinic_sales
        WHERE strftime('%Y', datetime) = '2021'
        GROUP BY strftime('%Y-%m', datetime)
    ),
    monthly_expense AS (
        SELECT strftime('%Y-%m', datetime) AS month, SUM(amount) AS expense
        FROM expenses
        WHERE strftime('%Y', datetime) = '2021'
        GROUP BY strftime('%Y-%m', datetime)
    )
SELECT 
    r.month,
    ifnull(r.revenue, 0) AS revenue,
    ifnull(e.expense, 0) AS expense,
    ifnull(r.revenue, 0) - ifnull(e.expense, 0) AS profit,
    CASE WHEN ifnull(r.revenue, 0) - ifnull(e.expense, 0) > 0 THEN 'profitable' ELSE 'not-profitable' END AS status
FROM monthly_revenue r
LEFT JOIN monthly_expense e ON r.month = e.month
ORDER BY r.month;
