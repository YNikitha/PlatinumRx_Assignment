SELECT
    sales_channel,
    SUM(amount) AS revenue
FROM clinic_sales
WHERE strftime('%Y', datetime) = '2021'    -- replace '2021' with your year
GROUP BY sales_channel;
