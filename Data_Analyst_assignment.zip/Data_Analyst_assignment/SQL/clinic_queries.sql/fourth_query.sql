WITH profits AS (
    SELECT
        cl.city,
        cs.cid,
        SUM(cs.amount) - ifnull(
            (SELECT SUM(amount) FROM expenses e WHERE e.cid = cs.cid AND strftime('%Y-%m', e.datetime) = '2021-09'),
            0
        ) AS profit
    FROM clinic_sales cs
    JOIN clinics cl ON cl.cid = cs.cid
    WHERE strftime('%Y-%m', cs.datetime) = '2021-09' -- Change to target month (e.g. '2021-09')
    GROUP BY cl.city, cs.cid
)
SELECT city, cid, profit
FROM (
    SELECT city, cid, profit,
        RANK() OVER (PARTITION BY city ORDER BY profit DESC) AS rnk
    FROM profits
)
WHERE rnk = 1;
