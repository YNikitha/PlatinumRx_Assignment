SELECT
    cs.uid,
    c.name,
    SUM(cs.amount) AS total_revenue
FROM clinic_sales cs
JOIN customer c ON c.uid = cs.uid
WHERE strftime('%Y', cs.datetime) = '2021' -- replace '2021' as needed
GROUP BY cs.uid
ORDER BY total_revenue DESC
LIMIT 10;
