WITH item_month_qty AS (
    SELECT
        strftime('%Y-%m', bill_date) AS mth,      -- month key
        item_id,
        SUM(item_quantity) AS total_qty
    FROM booking_commercials
    WHERE strftime('%Y', bill_date) = '2021'     -- only year 2021
    GROUP BY
        strftime('%Y-%m', bill_date),
        item_id
),
ranked AS (
    SELECT
        mth,
        item_id,
        total_qty,
        RANK() OVER (PARTITION BY mth ORDER BY total_qty DESC) AS rnk_desc,
        RANK() OVER (PARTITION BY mth ORDER BY total_qty ASC)  AS rnk_asc
    FROM item_month_qty
)
SELECT
    mth,
    item_id,
    total_qty,
    CASE
        WHEN rnk_desc = 1 THEN 'most_ordered'
        WHEN rnk_asc  = 1 THEN 'least_ordered'
    END AS tag
FROM ranked
WHERE rnk_desc = 1 OR rnk_asc = 1
ORDER BY mth, tag;
