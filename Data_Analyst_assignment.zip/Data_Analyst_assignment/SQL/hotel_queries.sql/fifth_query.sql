WITH bill_amounts AS (
    SELECT
        strftime('%Y-%m', bc.bill_date) AS mth,      -- month key
        bc.bill_id,
        b.user_id,
        SUM(bc.item_quantity * i.item_rate) AS bill_amount
    FROM booking_commercials bc
    JOIN bookings b
        ON b.booking_id = bc.booking_id
    JOIN items i
        ON i.item_id = bc.item_id
    WHERE strftime('%Y', bc.bill_date) = '2021'     -- only 2021
    GROUP BY
        strftime('%Y-%m', bc.bill_date),
        bc.bill_id,
        b.user_id
),
ranked AS (
    SELECT
        mth,
        bill_id,
        user_id,
        bill_amount,
        RANK() OVER (PARTITION BY mth ORDER BY bill_amount DESC) AS rnk
    FROM bill_amounts
)
SELECT
    mth,
    bill_id,
    user_id,
    bill_amount
FROM ranked
WHERE rnk = 2
ORDER BY mth, bill_amount DESC;
