SELECT b.booking_id,
       SUM(bc.item_quantity * i.item_rate) AS total_amount
FROM bookings b
JOIN booking_commercials bc
  ON bc.booking_id = b.booking_id
JOIN items i
  ON i.item_id = bc.item_id
WHERE b.booking_date >= '2021-11-01'
  AND b.booking_date <  '2021-12-01'
GROUP BY b.booking_id;
