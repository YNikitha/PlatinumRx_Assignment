BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "clinic_sales" (
	"oid"	TEXT,
	"uid"	TEXT,
	"cid"	TEXT,
	"amount"	REAL,
	"datetime"	TEXT,
	"sales_channel"	TEXT,
	PRIMARY KEY("oid"),
	FOREIGN KEY("cid") REFERENCES "clinics"("cid"),
	FOREIGN KEY("uid") REFERENCES "customer"("uid")
);
CREATE TABLE IF NOT EXISTS "clinics" (
	"cid"	TEXT,
	"clinic_name"	TEXT,
	"city"	TEXT,
	"state"	TEXT,
	"country"	TEXT,
	PRIMARY KEY("cid")
);
CREATE TABLE IF NOT EXISTS "customer" (
	"uid"	TEXT,
	"name"	TEXT,
	"mobile"	TEXT,
	PRIMARY KEY("uid")
);
CREATE TABLE IF NOT EXISTS "expenses" (
	"eid"	TEXT,
	"cid"	TEXT,
	"description"	TEXT,
	"amount"	REAL,
	"datetime"	TEXT,
	PRIMARY KEY("eid"),
	FOREIGN KEY("cid") REFERENCES "clinics"("cid")
);
INSERT INTO "clinic_sales" VALUES ('ord-00100-00100','bk-09f3e-95hj','cnc-0100001',24999.0,'2021-09-23 12:03:22','sodat');
INSERT INTO "clinics" VALUES ('cnc-0100001','XYZ clinic','lorem','ipsum','dolor');
INSERT INTO "customer" VALUES ('bk-09f3e-95hj','Jon Doe','97XXXXXXXX');
INSERT INTO "expenses" VALUES ('exp-0100-00100','cnc-0100001','first-aid supplies',557.0,'2021-09-23 07:36:48');
COMMIT;
