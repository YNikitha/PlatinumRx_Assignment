# Time Conversion Program

minutes = int(input("Enter total minutes: "))

hours = minutes // 60
remaining_minutes = minutes % 60

print(f"{hours} hrs {remaining_minutes} minutes")
